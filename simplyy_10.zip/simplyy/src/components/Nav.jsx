import { useState, useEffect } from "react";
import SimplyLogo from "./SimplyLogo";
import C from "../styles/colors";
import { NAV_LINKS } from "../data/content";

export default function Nav({ page, setPage }) {
  const [scrolled, setScrolled]   = useState(false);
  const [menuOpen, setMenuOpen]   = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  // Close menu on route change
  const go = (p) => { setPage(p); window.scrollTo(0, 0); setMenuOpen(false); };

  return (
    <>
      <nav style={{
        position:"fixed", top:0, left:0, right:0, zIndex:200,
        padding:"0 5%",
        background: scrolled || menuOpen ? "rgba(255,255,255,0.97)" : "transparent",
        backdropFilter: scrolled || menuOpen ? "blur(16px)" : "none",
        borderBottom: scrolled || menuOpen ? `1px solid ${C.border}` : "none",
        transition:"all 0.3s ease",
      }}>
        <div style={{ maxWidth:1200, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"space-between", height:64 }}>
          <button onClick={() => go("Home")} style={{ background:"none", border:"none", cursor:"pointer", padding:0 }}>
            <SimplyLogo size={30}/>
          </button>

          {/* Desktop links */}
          <div style={{ display:"flex", alignItems:"center", gap:2, "@media(max-width:768px)":{display:"none"} }} className="desk-nav">
            {NAV_LINKS.map(l => (
              <button key={l} onClick={() => go(l)}
                style={{ background: page===l ? C.blueLight : "none", border:"none", cursor:"pointer", padding:"7px 13px", borderRadius:7, fontSize:14, fontWeight:500, color: page===l ? C.blue : C.inkMid, transition:"all 0.15s" }}
                onMouseEnter={e => { e.currentTarget.style.background=C.bgOff; e.currentTarget.style.color=C.ink; }}
                onMouseLeave={e => { e.currentTarget.style.background=page===l?C.blueLight:"none"; e.currentTarget.style.color=page===l?C.blue:C.inkMid; }}
              >{l}</button>
            ))}
            <button onClick={() => go("Contact")}
              style={{ marginLeft:8, background:C.blue, color:"#fff", border:"none", cursor:"pointer", padding:"9px 20px", borderRadius:8, fontSize:14, fontWeight:600, transition:"all 0.2s", boxShadow:"0 1px 3px rgba(37,99,235,0.25)" }}
              onMouseEnter={e => { e.currentTarget.style.background=C.blueMid; e.currentTarget.style.transform="translateY(-1px)"; }}
              onMouseLeave={e => { e.currentTarget.style.background=C.blue; e.currentTarget.style.transform="none"; }}
            >Get Started</button>
          </div>

          {/* Hamburger */}
          <button className="mob-menu-btn"
            onClick={() => setMenuOpen(o => !o)}
            style={{ background:"none", border:"none", cursor:"pointer", padding:8, display:"none", flexDirection:"column", gap:5 }}
            aria-label="Toggle menu">
            <span style={{ display:"block", width:22, height:2, background:C.ink, borderRadius:2, transition:"all 0.25s", transform: menuOpen ? "rotate(45deg) translate(5px,5px)" : "none" }}/>
            <span style={{ display:"block", width:22, height:2, background:C.ink, borderRadius:2, transition:"all 0.25s", opacity: menuOpen ? 0 : 1 }}/>
            <span style={{ display:"block", width:22, height:2, background:C.ink, borderRadius:2, transition:"all 0.25s", transform: menuOpen ? "rotate(-45deg) translate(5px,-5px)" : "none" }}/>
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <div className="mob-drawer" style={{
        position:"fixed", top:64, left:0, right:0, zIndex:199,
        background:"#fff", borderBottom:`1px solid ${C.border}`,
        padding:"16px 5% 24px",
        transform: menuOpen ? "translateY(0)" : "translateY(-110%)",
        transition:"transform 0.3s ease",
        display:"none",
        flexDirection:"column", gap:4,
        boxShadow:"0 8px 24px rgba(0,0,0,0.08)",
      }}>
        {NAV_LINKS.map(l => (
          <button key={l} onClick={() => go(l)}
            style={{ background: page===l ? C.blueLight : "none", border:"none", cursor:"pointer", padding:"12px 16px", borderRadius:8, fontSize:15, fontWeight:500, color: page===l ? C.blue : C.inkMid, textAlign:"left", width:"100%" }}
          >{l}</button>
        ))}
        <button onClick={() => go("Contact")}
          style={{ marginTop:8, background:C.blue, color:"#fff", border:"none", cursor:"pointer", padding:"13px 16px", borderRadius:9, fontSize:15, fontWeight:700, width:"100%" }}
        >Get Started →</button>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .desk-nav { display: none !important; }
          .mob-menu-btn { display: flex !important; }
          .mob-drawer { display: flex !important; }
        }
      `}</style>
    </>
  );
}
